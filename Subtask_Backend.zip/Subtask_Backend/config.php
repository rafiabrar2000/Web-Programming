<?php
// config.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
mb_internal_encoding('UTF-8');

// === Database connection (update credentials) ===
const DB_HOST = '127.0.0.1';
const DB_NAME = 'taskmaster';
const DB_USER = 'root';
const DB_PASS = '';
const DSN = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(DSN, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    }
    return $pdo;
}

// === Read JSON Body ===
function read_json(): array {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Only POST requests allowed']);
        exit;
    }
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
        exit;
    }
    return $data;
}

// === Validators ===
function validate_id($v, string $field = 'id'): int {
    if (!is_numeric($v) || (int)$v <= 0) {
        throw new InvalidArgumentException("$field must be a positive integer");
    }
    return (int)$v;
}

function validate_name(?string $name, string $field = 'name'): string {
    $name = trim((string)$name);
    if ($name === '') throw new InvalidArgumentException("$field is required");
    if (strlen($name) > 180) throw new InvalidArgumentException("$field too long");
    if (!preg_match('/^[A-Za-z0-9 _-]+$/', $name))
        throw new InvalidArgumentException("$field contains invalid characters");
    return $name;
}

function validate_description(?string $text): ?string {
    if ($text === null) return null;
    $text = trim($text);
    if ($text === '') return null;
    if (strlen($text) > 2000) throw new InvalidArgumentException("Description too long");
    if (preg_match('/[<>]/', $text)) throw new InvalidArgumentException("Description contains forbidden characters (< or >)");
    return $text;
}

function validate_date(?string $date, string $field = 'duedate'): ?string {
    if ($date === null || $date === '') return null;
    $d = DateTime::createFromFormat('Y-m-d', $date);
    if (!$d || $d->format('Y-m-d') !== $date) {
        throw new InvalidArgumentException("$field must be in YYYY-MM-DD format");
    }
    return $date;
}

function validate_email(?string $email): string {
    $email = trim((string)$email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException("Invalid email format");
    }
    return $email;
}

// === Check existence ===
function check_task_exists(PDO $db, int $task_id): void {
    $st = $db->prepare('SELECT id FROM task WHERE id=?');
    $st->execute([$task_id]);
    if (!$st->fetch()) throw new InvalidArgumentException("task_id not found");
}

function check_worker_exists(PDO $db, int $worker_id): void {
    $st = $db->prepare('SELECT id FROM worker WHERE id=?');
    $st->execute([$worker_id]);
    if (!$st->fetch()) throw new InvalidArgumentException("worker_id not found");
}

function find_worker_by_email(PDO $db, ?string $email): ?int {
    if (!$email) return null;
    $email = validate_email($email);
    $st = $db->prepare('SELECT w.id AS worker_id FROM user u JOIN worker w ON w.user_id=u.id WHERE u.email=? LIMIT 1');
    $st->execute([$email]);
    $row = $st->fetch();
    if (!$row) throw new InvalidArgumentException("No worker found for email $email");
    return (int)$row['worker_id'];
}

// === Recompute parent task status ===
function update_task_status(PDO $db, int $task_id): void {
    $st = $db->prepare("SELECT 
        COUNT(*) AS total,
        SUM(status='completed') AS done,
        SUM(status='in_progress') AS prog,
        SUM(status='blocked') AS blk
        FROM subtask WHERE task_id=?");
    $st->execute([$task_id]);
    $r = $st->fetch();

    if (!$r || (int)$r['total'] === 0) return;

    $new = 'new';
    if ((int)$r['done'] === (int)$r['total']) $new = 'completed';
    elseif ((int)$r['prog'] > 0 || (int)$r['blk'] > 0) $new = 'in_progress';

    $u = $db->prepare('UPDATE task SET status=? WHERE id=?');
    $u->execute([$new, $task_id]);
}

function error_response(Throwable $e, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    exit;
}
