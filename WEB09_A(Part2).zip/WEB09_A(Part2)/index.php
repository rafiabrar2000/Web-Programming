<?php
   $i = 1;
   $j = 2;
   $r = $i + $j;
   echo "The summation is:" . $r . "<br>";

   for($k = 1 ; $k < 6 ; $k++){
       echo $k . "<br>";
   }

   for($l =1 ; $l <=10 ;$l++){
    if($l%2==0){
        echo $l." Is even Number"."<br>";
    }
    else{
        echo $l." Is odd Number"."<br>";
    }
   }

   function evenOdd($count){
       for($m =1 ; $m <= $count ;$m++){
          if($m%2==0){
              echo $m." Is even Number"."<br>";
          }
          else{
              echo $m." Is odd Number"."<br>";
          }
   }
   }
   evenOdd(10);
?>