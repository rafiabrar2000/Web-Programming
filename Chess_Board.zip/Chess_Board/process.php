<?php
// process.php — session-backed but with NO pieces
session_start();
header('Content-Type: application/json');

function initial_board() {
  // 8x8 empty
  return [
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
  ];
}

function ensure_state() {
  if (!isset($_SESSION['board'])) {
    $_SESSION['board'] = initial_board();
    $_SESSION['turn'] = 'w'; // unused, but kept for compatibility
  }
}

$action = $_POST['action'] ?? $_GET['action'] ?? 'peek';
ensure_state();

switch ($action) {
  case 'init':
    echo json_encode([
      'ok'=>true,
      'board'=>$_SESSION['board'],
      'turn'=>$_SESSION['turn'],
      'message'=>'Board initialized (no pieces).'
    ]);
    break;

  case 'peek':
    echo json_encode([
      'ok'=>true,
      'board'=>$_SESSION['board'],
      'turn'=>$_SESSION['turn'],
      'message'=>null
    ]);
    break;

  case 'reset':
    $_SESSION['board'] = initial_board();
    $_SESSION['turn'] = 'w';
    echo json_encode([
      'ok'=>true,
      'board'=>$_SESSION['board'],
      'turn'=>$_SESSION['turn'],
      'message'=>'Reset to empty board.'
    ]);
    break;

  case 'move':
    // No players/pieces present
    echo json_encode(['ok'=>false, 'message'=>'Moves are disabled: no players on the board.']);
    break;

  default:
    echo json_encode(['ok'=>false, 'message'=>'Unknown action.']);
}
