<?php
// Basic validation helpers
function get_post_number($key, $default = 0) {
    if (!isset($_POST[$key]) || $_POST[$key] === '') return $default;
    return is_numeric($_POST[$key]) ? (float)$_POST[$key] : $default;
}
function get_post_string($key, $default = '') {
    return isset($_POST[$key]) ? trim($_POST[$key]) : $default;
}

// Read inputs
$quantity = (int) get_post_number('quantity', 0);
$hdInput  = get_post_string('hd', 'no'); // 'yes' or 'no'
$address  = get_post_string('address', '');
$tip      = get_post_number('tip', 0);

// Server-side validation
$errors = [];
if ($quantity < 0)            { $errors[] = "Quantity cannot be negative."; }
if ($quantity === 0)          { $errors[] = "Please enter a quantity greater than 0."; }
if ($tip < 0)                 { $errors[] = "Tip cannot be negative."; }
if (!in_array($hdInput, ['yes', 'no'], true)) { $errors[] = "Invalid Home Delivery selection."; }
if (!in_array($address, ['dhk', 'ctg'], true)) { $errors[] = "Please select a valid city."; }

if (!empty($errors)) {
    // Show errors and a back link
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bill Error</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 540px; margin: 40px auto; }
            .error { background: #ffe8e8; border: 1px solid #ffb3b3; padding: 12px; border-radius: 8px; }
            ul { margin: 8px 0; }
            a { display: inline-block; margin-top: 12px; }
        </style>
    </head>
    <body>
        <h2>There were some problems with your input</h2>
        <div class="error">
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <a href="index.html">← Go back</a>
    </body>
    </html>
    <?php
    exit;
}

// Calculation (mirrors your JS logic)
$base = $quantity * 12.5;

// Quantity discounts
if ($quantity >= 1 && $quantity <= 9) {
    $base *= 0.90;
} elseif ($quantity >= 10 && $quantity <= 19) {
    $base *= 0.85;
} elseif ($quantity >= 20) {
    $base *= 0.80;
}

// Home delivery charge
if ($hdInput === 'yes') {
    $base += 40;
}

// City adjustment
if ($address === 'dhk') {
    $base *= 1.20;
} else { // 'ctg'
    $base *= 1.15;
}

// Add tip
$base += $tip;

// Format to 2 decimals
$total = number_format($base, 2, '.', '');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Total Bill</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 540px; margin: 40px auto; line-height: 1.6; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 16px; }
    .total { font-size: 1.4rem; font-weight: bold; }
    a { display: inline-block; margin-top: 14px; }
    .row { margin: 4px 0; }
    .label { color: #555; width: 160px; display: inline-block; }
  </style>
</head>
<body>
  <h2>Bill Summary</h2>
  <div class="card">
    <div class="row"><span class="label">Quantity:</span> <?php echo htmlspecialchars((string)$quantity, ENT_QUOTES, 'UTF-8'); ?></div>
    <div class="row"><span class="label">Home Delivery:</span> <?php echo $hdInput === 'yes' ? 'Yes' : 'No'; ?></div>
    <div class="row"><span class="label">City:</span> <?php echo $address === 'dhk' ? 'Dhaka' : 'Chittagong'; ?></div>
    <div class="row"><span class="label">Tip (BDT):</span> <?php echo htmlspecialchars(number_format($tip, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></div>
    <hr>
    <div class="total">Your total bill is <?php echo $total; ?> BDT</div>
  </div>

  <a href="index.html">← Calculate again</a>
</body>
</html>
