<?php
  $salary = $_POST['size'];
  $salary = $salary  * 1.1; //10% increment
  echo "Your salary incremented is: $salary";
?>